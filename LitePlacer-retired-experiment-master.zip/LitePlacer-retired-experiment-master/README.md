# LitePlacer

This is the forum user "thereza"s rewrite of the software. In time, I anticipate this revision will become the "official" supported version. for now, please consider this as an unsupported, development branch.

